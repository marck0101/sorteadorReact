// import logo from './logo.svg';
import "./App.css";
import Index from "./componentes";
// import NewTaskInput from "./componentes/lista/lista";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Index />
        {/* <NewTaskInput /> */}
      </header>
    </div>
  );
}

export default App;
